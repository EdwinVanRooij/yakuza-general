function start() {
	cm.sendOk("Will I ever finish cleaning? This ship is just too big...");
	cm.dispose();
}