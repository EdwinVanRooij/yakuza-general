function start(ms) { 
	ms.openNpc(2159012);
}