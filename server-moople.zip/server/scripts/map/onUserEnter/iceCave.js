function start(ms) {
	ms.teachSkill(20000014, -1, 0, -1);
	ms.teachSkill(20000015, -1, 0, -1);
	ms.teachSkill(20000016, -1, 0, -1);
	ms.teachSkill(20000017, -1, 0, -1);
	ms.teachSkill(20000018, -1, 0, -1);
	ms.unlockUI();
	ms.showIntro("Effect/Direction1.img/aranTutorial/ClickLilin");
}