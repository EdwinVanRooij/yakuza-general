function start(ms) { 
	ms.setDirectionMode(false);
}