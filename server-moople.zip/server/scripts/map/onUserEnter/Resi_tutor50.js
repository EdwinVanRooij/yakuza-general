function start(ms) { 
	ms.setDirectionMode(false);
	ms.openNpc(2159006);
}