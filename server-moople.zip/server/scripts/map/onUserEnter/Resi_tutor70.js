function start(ms) { 
	ms.setDirectionMode(true);
	ms.showIntro("Effect/Direction4.img/Resistance/TalkJ");
}