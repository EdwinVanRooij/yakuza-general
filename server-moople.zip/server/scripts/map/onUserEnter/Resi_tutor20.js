function start(ms) { 
	ms.mapEffect("resistance/tutorialGuide");
}