function start(ms) { 
        ms.getPlayer().resetEnteredScript(); 
	ms.getPlayer().getMap().addMapTimer(180);
	ms.spawnMonster(9300331, -28, 0);
}  