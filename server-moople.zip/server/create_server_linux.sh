export CLASSPATH=.:"../Source/out/artifacts/JavaProjIntelliJ_jar/JavaProjIntelliJ.jar"
java -Xmx100m net.server.CreateINI
